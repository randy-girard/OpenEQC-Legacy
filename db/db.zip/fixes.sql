CREATE TABLE `account` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `lsadmin` tinyint(2) unsigned NOT NULL default '0',
  `lsstatus` int(11) unsigned default NULL,
  `worldadmin` tinyint(3) unsigned NOT NULL default '0',
  `user_active` tinyint(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `lsstatus` (`lsstatus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;