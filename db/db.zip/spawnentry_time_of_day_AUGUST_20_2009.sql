/*
MySQL Data Transfer
Source Host: localhost
Source Database: eqc
Target Host: localhost
Target Database: eqc
Date: 8/20/2009 1:16:07 PM
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Update table structure for spawnentry
-- ----------------------------
ALTER TABLE spawnentry ADD time_of_day tinyint(1) NOT NULL DEFAULT 0;