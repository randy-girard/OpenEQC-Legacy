/*
MySQL Data Transfer
Source Host: localhost
Source Database: eqc3
Target Host: localhost
Target Database: eqc3
Date: 7/6/2009 2:03:27 PM
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for zone
-- ----------------------------
DROP TABLE IF EXISTS `zone`;
CREATE TABLE `zone` (
  `short_name` varchar(16) NOT NULL default '',
  `file_name` varchar(16) default NULL,
  `long_name` text,
  `safe_x` float NOT NULL default '0',
  `safe_y` float NOT NULL default '0',
  `safe_z` float NOT NULL default '0',
  `safe_heading` float NOT NULL default '0',
  `safe_gm_x` float NOT NULL default '0',
  `safe_gm_y` float NOT NULL default '0',
  `safe_gm_z` float NOT NULL default '0',
  `safe_gm_heading` float NOT NULL default '0',
  `minium_level` tinyint(3) unsigned NOT NULL default '0',
  `minium_status` tinyint(3) unsigned NOT NULL default '0',
  `weather` tinyint(1) default NULL,
  PRIMARY KEY  (`short_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `zone` VALUES ('airplane', null, 'Plane of Sky','576','1411','-666','121','0','0','0','0', '46', '0', '1');
INSERT INTO `zone` VALUES ('akanon', null, 'Ak\'Anon','22','367','-28','128','22','367','-24','128', '0', '0', '0');
INSERT INTO `zone` VALUES ('arena', null, 'The Arena','-490','-5','1','64','-490','-5','5','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('befallen', null, 'Befallen','11','-76','0','192','11','-76','4','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('beholder', null, 'Gorge of King Xorbb','-30','-511','41','0','-30','-511','45','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('blackburrow', null, 'Blackburrow','14','-161','0','64','14','-161','4','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('burningwood', null, 'The Burning Wood','-820','-4941','200','0','-820','-4941','204','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('butcher', null, 'Butcherblock Mountains','-699','2550','0','224','-699','2550','3','224', '0', '0', '1');
INSERT INTO `zone` VALUES ('cabeast', null, 'Cabilis East','-414','1343','0','128','-414','1343','4','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('cabwest', null, 'Cabilis West','756','-782','0','192','756','-782','4','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('cauldron', null, 'Dagnor\'s Cauldron','320','2815','469','135','320','2815','473','135', '0', '0', '1');
INSERT INTO `zone` VALUES ('cazicthule', null, 'Lost Temple of CazicThule','-62','71','0','64','-62','71','4','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('charasis', null, 'The Howling Stones','0','0','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('chardok', null, 'Chardok','931','-99','100','192','931','-99','104','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('citymist', null, 'The City of Mist','-856','0','0','64','-856','0','4','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('cobaltscar', null, 'Cobalt Scar','-155','-812','83','192','-155','-812','87','192', '0', '0', '2');
INSERT INTO `zone` VALUES ('commons', null, 'West Commonlands','-1333','214','-55','64','-1333','214','-51','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('crushbone', null, 'Crushbone','161','-660','0','0','161','-660','4','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('crystal', null, 'Crystal Caverns','304','488','-80','192','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('cshome', null, 'EQClassic Guide Zone','0','0','0','0','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('dalnir', null, 'Dalnir','80','6','0','192','80','6','4','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('dreadlands', null, 'Dreadlands','9566','2806','1041','128','9566','2806','1045','128', '0', '0', '2');
INSERT INTO `zone` VALUES ('droga', null, 'Mines of Droga','342','1382','0','192','342','1382','4','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('eastkarana', null, 'Eastern Plains of Karana','865','15','-37','192','865','15','-33','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('eastwastes', null, 'Eastern Wastelands','-5679','-4485','552','64','-5679','-4485','556','64', '0', '0', '2');
INSERT INTO `zone` VALUES ('ecommons', null, 'East Commonlands','4947','8','-74','192','4947','8','-70','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('emeraldjungle', null, 'The Emerald Jungle','4648','-1222','-1','177','4648','-1222','2','177', '0', '0', '1');
INSERT INTO `zone` VALUES ('erudnext', null, 'Erudin','0','0','20','0','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('erudnint', null, 'Erudin Palace','780','712','0','192','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('erudsxing', null, 'Erud\'s Crossing','795','-1766','8','192','795','-1766','8','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('everfrost', null, 'Everfrost','629','3139','-64','242','629','3139','-64','242', '0', '0', '2');
INSERT INTO `zone` VALUES ('fearplane', null, 'Plane of Fear','1033','-814','103','128','1033','-814','103','128', '46', '0', '1');
INSERT INTO `zone` VALUES ('feerrott', null, 'The Feerrott','905','1051','22','0','905','1051','22','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('felwithea', null, 'Northern Felwithe','136','-28','0','192','136','-28','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('felwitheb', null, 'Southern Felwithe','-791','277','-14','0','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('fieldofbone', null, 'Field of Bone','3244','-2393','6','216','3244','-2393','6','216', '0', '0', '1');
INSERT INTO `zone` VALUES ('firiona', null, 'Firiona Vie','1440','-2391','-6','92','1440','-2391','-6','92', '0', '0', '1');
INSERT INTO `zone` VALUES ('freporte', null, 'East Freeport','0','0','0','192','0','0','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('freportn', null, 'North Freeport','0','0','0','192','0','0','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('freportw', null, 'West Freeport','0','0','0','44','0','0','0','44', '0', '0', '1');
INSERT INTO `zone` VALUES ('frontiermtns', null, 'Frontier Mountains','-4261','-632','110','64','-4261','-632','110','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('frozenshadow', null, 'Tower of Frozen Shadow','200','100','0','0','0','0','0','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('gfaydark', null, 'Greater Faydark','0','0','0','206','0','0','0','206', '0', '0', '1');
INSERT INTO `zone` VALUES ('greatdivide', null, 'Great Divide','132','-2348','-86','192','0','0','-68','192', '0', '0', '2');
INSERT INTO `zone` VALUES ('grobb', null, 'Grobb','0','0','0','7','0','0','0','7', '0', '0', '1');
INSERT INTO `zone` VALUES ('growthplane', null, 'Plane of Growth','0','0','0','57','0','0','0','57', '46', '0', '1');
INSERT INTO `zone` VALUES ('gukbottom', null, 'Ruins of Old Guk','662','1154','-94','64','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('guktop', null, 'Guk','35','-35','0','192','35','-35','0','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('halas', null, 'Halas','0','0','0','0','0','0','0','0', '0', '0', '2');
INSERT INTO `zone` VALUES ('hateplane', null, 'Plane of Hate','0','0','0','0','0','0','0','0', '46', '0', '0');
INSERT INTO `zone` VALUES ('highkeep', null, 'High Keep','-4','-14','-6','192','-4','-14','-6','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('highpass', null, 'Highpass Hold','-11','-13','0','192','-11','-13','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('hole', null, 'The Hole','220','792','0','126','0','0','0','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('iceclad', null, 'Iceclad Ocean','361','5328','-20','64','361','5328','-20','64', '0', '0', '2');
INSERT INTO `zone` VALUES ('innothule', null, 'Innothule Swamp','-587','-2191','-27','64','-587','-2191','-27','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('kael', null, 'Kael Drakael','-630','-48','120','128','-630','-48','120','128', '0', '0', '0');
INSERT INTO `zone` VALUES ('kaesora', null, 'Kaesora','40','200','48','128','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('kaladima', null, 'North Kaladim','0','0','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('kaladimb', null, 'South Kaladim','-219','440','0','60','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('karnor', null, 'Karnor\'s Castle','308','17','0','192','308','17','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('kedge', null, 'Kedge Keep','3','100','300','128','3','100','300','128', '0', '0', '0');
INSERT INTO `zone` VALUES ('kerraridge', null, 'Kerra Isle','106','-160','6','0','106','-160','6','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('kithicor', null, 'Kithicor Woods','3828','1889','456','236','3828','1889','456','236', '0', '0', '1');
INSERT INTO `zone` VALUES ('kurn', null, 'Kurn\'s Tower','0','0','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('lakeofillomen', null, 'Lake of Ill Omen','-6403','6248','35','92','-6403','6248','35','92', '0', '0', '1');
INSERT INTO `zone` VALUES ('lakerathe', null, 'Lake Rathetear','1211','4158','0','123','1211','4158','0','123', '0', '0', '1');
INSERT INTO `zone` VALUES ('lavastorm', null, 'Lavastorm Mountains','154','-1832','-18','253','154','-1832','-18','253', '0', '0', '0');
INSERT INTO `zone` VALUES ('lfaydark', null, 'Lesser Faydark','-1769','-107','-4','138','-1769','-107','-4','138', '0', '0', '1');
INSERT INTO `zone` VALUES ('load', null, 'Loading Zone','-397','-1411','112','0','0','0','0','0', '0', '100', '0');
INSERT INTO `zone` VALUES ('mischiefplane', null, 'Plane of Mischief','153','-294','-181','64','22','-157','-84','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('mistmoore', null, 'Castle Mistmoore','0','0','0','64','0','0','0','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('misty', null, 'Misty Thicket','815','-74','0','192','815','-74','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('najena', null, 'Najena','2000','-100','0','203','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('necropolis', null, 'Dragon Necropolis','0','0','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('nektulos', null, 'Nektulos Forest','-258','-1200','-8','43','-258','-1200','-8','43', '0', '0', '1');
INSERT INTO `zone` VALUES ('neriaka', null, 'Neriak Foreign Quarter','144','0','28','192','144','0','28','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('neriakb', null, 'Neriak Commons','-559','-55','-41','60','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('neriakc', null, 'Neriak Third Gate','-810','694','-56','128','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('northkarana', null, 'Northern Plains of Karana','-381','-283','-11','128','-381','-283','-11','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('nro', null, 'Northern Desert of Ro','299','3538','-28','128','299','3538','-28','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('nurga', null, 'Mines of Nurga','-1719','-2185','-10','25','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('oasis', null, 'Oasis of Marr','904','450','2','150','904','450','2','150', '0', '0', '1');
INSERT INTO `zone` VALUES ('oggok', null, 'Oggok','-68','-349','0','64','-68','-349','0','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('oot', null, 'Ocean of Tears','-9199','390','2','128','-9199','390','2','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('overthere', null, 'The Overthere','-4201','-222','229','52','-4201','-222','229','52', '0', '0', '1');
INSERT INTO `zone` VALUES ('paineel', null, 'Paineel','800','200','0','128','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('paw', null, 'Lair of the Splitpaw','-8','-62','0','0','-8','-62','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('permafrost', null, 'Permafrost Caverns','167','-60','0','192','167','-60','0','192', '0', '0', '0');
INSERT INTO `zone` VALUES ('qcat', null, 'Qeynos Aqueduct System','-185','289','-42','128','-185','289','-42','128', '0', '0', '0');
INSERT INTO `zone` VALUES ('qey2hh1', null, 'Western Plains of Karana','-15918','-4198','-58','64','-15918','-4198','-58','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('qeynos', null, 'South Qeynos','91','13','0','192','91','13','0','192', '0', '0', '1');
INSERT INTO `zone` VALUES ('qeynos2', null, 'North Qeynos','0','0','0','64','0','0','0','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('qeytoqrg', null, 'Qeynos Hills','83','508','-6','0','83','508','-6','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('qrg', null, 'Surefall Glade','0','0','0','0','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('rathemtn', null, 'Rathe Mountains','1831','3825','25','128','1831','3825','25','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('rivervale', null, 'Rivervale','0','0','0','203','0','0','0','203', '0', '0', '1');
INSERT INTO `zone` VALUES ('runnyeye', null, 'Runnyeye Citadel','-19','-98','0','18','-19','-98','0','18', '0', '0', '0');
INSERT INTO `zone` VALUES ('sebilis', null, 'Old Sebilis','0','216','36','128','0','216','36','128', '0', '0', '0');
INSERT INTO `zone` VALUES ('sirens', null, 'Sirens Grotto','-61','198','0','64','-61','198','0','64', '0', '0', '0');
INSERT INTO `zone` VALUES ('skyfire', null, 'Skyfire Mountains','154','-1823','-185','160','154','-1823','-185','160', '0', '0', '0');
INSERT INTO `zone` VALUES ('skyshrine', null, 'Skyshrine','-730','-209','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('sleeper', null, 'Sleepers Tomb','0','0','0','64','0','0','0','64', '0', '0', '0');
INSERT INTO `zone` VALUES ('soldunga', null, 'Solusek\'s Eye','-508','-453','70','64','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('soldungb', null, 'Nagafen\'s Lair','-256','-423','-111','64','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('soltemple', null, 'Temple of Solusek Ro','40','261','0','192','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('southkarana', null, 'Southern Plains of Karana','1294','2348','-8','226','1294','2348','-8','226', '0', '0', '1');
INSERT INTO `zone` VALUES ('sro', null, 'Southern Desert of Ro','286','1265','75','128','286','1265','75','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('steamfont', null, 'Steamfont Mountains','-272','160','-24','172','-272','160','-24','172', '0', '0', '1');
INSERT INTO `zone` VALUES ('stonebrunt', null, 'Stonebrunt Mountains','0','0','0','0','0','0','0','0', '0', '0', '2');
INSERT INTO `zone` VALUES ('swampofnohope', null, 'Swamp Of No Hope','2945','2761','0','152','2945','2761','0','152', '0', '0', '1');
INSERT INTO `zone` VALUES ('templeveeshan', null, 'Temple of Veeshan','-500','-2025','-49','0','0','0','0','0', '46', '0', '0');
INSERT INTO `zone` VALUES ('thurgadina', null, 'City of Thurgadin','5','-880','10','0','5','-880','10','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('thurgadinb', null, 'Icewell Keep','5','137','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('timorous', null, 'Timorous Deep','2194','-5391','1','72','2194','-5391','1','72', '0', '0', '1');
INSERT INTO `zone` VALUES ('tox', null, 'Toxxulia Forest','205','2295','-48','0','205','2295','-48','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('trakanon', null, 'Trakanon\'s Teeth','1495','3897','-343','128','1495','3897','-343','128', '0', '0', '1');
INSERT INTO `zone` VALUES ('tutorial', null, 'The Tutorial Zone','0','0','0','0','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('unrest', null, 'Estate of Unrest','0','0','0','0','0','0','0','0', '0', '0', '1');
INSERT INTO `zone` VALUES ('veeshan', null, 'Veeshan\'s Peak','1679','40','24','5','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('velketor', null, 'Velketor\'s Labrynth','0','0','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('vexthal', null, 'Vex Thal','-123','581','-156','128','-123','581','-156','128', '0', '0', null);
INSERT INTO `zone` VALUES ('wakening', null, 'The Wakening Lands','-4840','-680','-198','64','-4840','-680','-198','64', '0', '0', '1');
INSERT INTO `zone` VALUES ('warrens', null, 'Warrens','0','0','0','0','0','0','0','0', '0', '0', '0');
INSERT INTO `zone` VALUES ('warslikswood', null, 'Warslilks Woods','-467','-1428','194','10','-467','-1428','194','10', '0', '0', '1');
INSERT INTO `zone` VALUES ('westwastes', null, 'Western Wastelands','-3820','-5137','-250','0','-3820','-5137','-250','0', '0', '0', '2');