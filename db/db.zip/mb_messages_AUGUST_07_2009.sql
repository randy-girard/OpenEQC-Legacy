/*
Navicat MySQL Data Transfer

Source Server         : EQC
Source Server Version : 40122
Source Host           : localhost:3306
Source Database       : eqclassic

Target Server Type    : MYSQL
Target Server Version : 40122
File Encoding         : 65001

Date: 2009-08-09 16:23:51
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `mb_messages`
-- ----------------------------
DROP TABLE IF EXISTS `mb_messages`;
CREATE TABLE `mb_messages` (
  `id` int(11) NOT NULL default '0',
  `date` varchar(10) NOT NULL default '',
  `author` varchar(30) NOT NULL default '',
  `language` tinyint(4) NOT NULL default '0',
  `subject` varchar(30) NOT NULL default '',
  `message` text NOT NULL,
  `category` tinyint(4) NOT NULL default '0',
  `time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mb_messages
-- ----------------------------
INSERT INTO `mb_messages` VALUES ('1', '2110062415', 'Harakiri', '0', 'Welcome to EQC!', 'Welcome to EQC!', '0', '1249827676');