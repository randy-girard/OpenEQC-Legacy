/*
Navicat MySQL Data Transfer
Source Host     : localhost:3306
Source Database : eqc
Target Host     : localhost:3306
Target Database : eqc
Date: 2009-07-30 19:51:33
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for time_of_day
-- ----------------------------
DROP TABLE IF EXISTS `time_of_day`;
CREATE TABLE `time_of_day` (
  `hour` tinyint(4) NOT NULL default '0',
  `day` tinyint(4) NOT NULL default '0',
  `month` tinyint(4) NOT NULL default '0',
  `year` bigint(20) NOT NULL default '0',
  `is_daytime` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`hour`,`day`,`month`,`year`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of time_of_day
-- ----------------------------
INSERT INTO `time_of_day` VALUES ('10', '9', '9', '2021', '1');
