/*
Navicat MySQL Data Transfer

Source Server         : EQC
Source Server Version : 40122
Source Host           : localhost:3306
Source Database       : ax_classic

Target Server Type    : MYSQL
Target Server Version : 40122
File Encoding         : 65001

Date: 2009-08-29 02:18:09
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `quest_globals`
-- ----------------------------
DROP TABLE IF EXISTS `quest_globals`;
CREATE TABLE `quest_globals` (
  `id` int(11) NOT NULL auto_increment,
  `charid` int(11) NOT NULL default '0',
  `npcid` int(11) NOT NULL default '0',
  `zoneid` int(11) NOT NULL default '0',
  `name` varchar(65) NOT NULL default '',
  `value` varchar(65) NOT NULL default '?',
  `expdate` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `qname` (`name`,`charid`,`npcid`,`zoneid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of quest_globals
-- ----------------------------
